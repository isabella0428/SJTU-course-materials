#include <iostream>
#include <map>
#include <vector>
#include <stack>
#include "topo.h"
using namespace std;

int main()
{
    create_graph();
    topo_sort();
    return 0;
}
