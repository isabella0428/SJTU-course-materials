#include <iostream>
#include "score.h"
using namespace std;


int main() {
    list scoreList;
    scoreList.quickSort();
    return 0;
}